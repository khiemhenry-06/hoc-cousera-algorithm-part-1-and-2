import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final int n;
    private final boolean[] opened;
    private final WeightedQuickUnionUF ufWithBottom;
    private final WeightedQuickUnionUF ufWithoutBottom;
    private final int virtualTop;
    private final int virtualBottom;
    private int openSitesCount;

    // Creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Grid size n must be greater than 0");
        }
        this.n = n;
        int totalSites = n * n;
        this.opened = new boolean[totalSites + 1];
        this.openSitesCount = 0;

        this.virtualTop = 0;
        this.virtualBottom = totalSites + 1;

        // ufWithBottom contains virtualTop and virtualBottom
        this.ufWithBottom = new WeightedQuickUnionUF(totalSites + 2);
        // ufWithoutBottom only contains virtualTop to prevent backwash
        this.ufWithoutBottom = new WeightedQuickUnionUF(totalSites + 1);
    }

    private int getIndex(int row, int col) {
        return (row - 1) * n + col;
    }

    private void validate(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n) {
            throw new IllegalArgumentException("Row and column indices must be between 1 and " + n);
        }
    }

    // Opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        validate(row, col);

        if (isOpen(row, col)) {
            return;
        }

        int currentIndex = getIndex(row, col);
        opened[currentIndex] = true;
        openSitesCount++;

        // Connect to virtual top if in the first row
        if (row == 1) {
            ufWithBottom.union(currentIndex, virtualTop);
            ufWithoutBottom.union(currentIndex, virtualTop);
        }

        // Connect to virtual bottom if in the last row
        if (row == n) {
            ufWithBottom.union(currentIndex, virtualBottom);
        }

        // Connect to neighboring open sites (Up, Down, Left, Right)
        if (row > 1 && isOpen(row - 1, col)) {
            int topIndex = getIndex(row - 1, col);
            ufWithBottom.union(currentIndex, topIndex);
            ufWithoutBottom.union(currentIndex, topIndex);
        }
        if (row < n && isOpen(row + 1, col)) {
            int bottomIndex = getIndex(row + 1, col);
            ufWithBottom.union(currentIndex, bottomIndex);
            ufWithoutBottom.union(currentIndex, bottomIndex);
        }
        if (col > 1 && isOpen(row, col - 1)) {
            int leftIndex = getIndex(row, col - 1);
            ufWithBottom.union(currentIndex, leftIndex);
            ufWithoutBottom.union(currentIndex, leftIndex);
        }
        if (col < n && isOpen(row, col + 1)) {
            int rightIndex = getIndex(row, col + 1);
            ufWithBottom.union(currentIndex, rightIndex);
            ufWithoutBottom.union(currentIndex, rightIndex);
        }
    }

    // Is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        validate(row, col);
        return opened[getIndex(row, col)];
    }

    // Is the site (row, col) full?
    public boolean isFull(int row, int col) {
        validate(row, col);
        if (!isOpen(row, col)) {
            return false;
        }
        return ufWithoutBottom.find(getIndex(row, col)) == ufWithoutBottom.find(virtualTop);
    }

    // Returns the number of open sites
    public int numberOfOpenSites() {
        return openSitesCount;
    }

    // Does the system percolate?
    public boolean percolates() {
        return ufWithBottom.find(virtualTop) == ufWithBottom.find(virtualBottom);
    }

    // Test client (optional)
    public static void main(String[] args) {
        // Có thể để trống hoặc viết kiểm thử đơn giản
    }
}